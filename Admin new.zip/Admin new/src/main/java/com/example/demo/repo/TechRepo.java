package com.example.demo.repo;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;


import com.example.demo.pojo.Technology;

public interface TechRepo extends CrudRepository<Technology, Long> {
	 
	@Query(value="select * from tech u where u.id = ?1 ",nativeQuery = true)
    Technology searchUser(long id);
	
	

	

	}
