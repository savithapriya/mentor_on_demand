package com.spring.project.repo;

import org.springframework.data.repository.CrudRepository;

import com.spring.project.pojo.TrainerDetails;

public interface TrainerRepo extends CrudRepository<TrainerDetails, Long>{

}
